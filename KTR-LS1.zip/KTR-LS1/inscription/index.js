(() => {
    'use strict'
    const forms = document.querySelectorAll('.needs-validation')

    Array.from(forms).forEach(form => {
      form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }
        form.classList.add('was-validated')
        event.preventDefault()
        event.stopPropagation()

        const phone = document.getElementById('phone').value
        const nameuser = document.getElementById('nameuser').value
        const nameCompany = document.getElementById('nameCompany').value
        const emailAdress = document.getElementById('emailAdress').value
        if (!nameuser) {
          return
        } else {
          localStorage.setItem('userinfos', JSON.stringify({ phone, nameuser, nameCompany, emailAdress }))
          window.location.replace("../login/index.html");
        }

      }, false)
    })

  })()