 (() => {
    'use strict'

    const userinfos = localStorage.getItem('userinfos');
    const parseUserInfos = JSON.parse(userinfos)
    if (!parseUserInfos) {
        window.location.replace("./inscription/index.html");
        return
    }
    document.getElementById("nameofficial").innerHTML = parseUserInfos.nameuser;
    const logout = document.getElementById("logout")
    logout.addEventListener("click", checkboxClick, false);

    function checkboxClick(event) {
        event.preventDefault();
        localStorage.removeItem('userinfos');
        localStorage.clear();
        window.location.replace("./inscription/index.html");
    }

})()