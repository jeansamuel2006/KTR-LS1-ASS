(() => {
    'use strict'

    let userinfos = localStorage.getItem('userinfos');
    const parseUserInfos = JSON.parse(userinfos)
    if (!parseUserInfos) {
      window.location.replace("../inscription/index.html");
    }

    const forms = document.querySelectorAll('.needs-validation.form-login')
    Array.from(forms).forEach(form => {
      form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }
        event.preventDefault()
        event.stopPropagation()
        form.classList.add('was-validated')
        const userpassword = document.getElementById('password').value

        if (userpassword !== '') {
          const newuser = Object.assign(parseUserInfos, {'userpassword': userpassword});
          localStorage.setItem('userinfos', JSON.stringify(newuser))
          window.location.replace("../index.html");
        }

      }, false)
    })
  })()