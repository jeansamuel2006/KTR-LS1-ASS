
(() => {
    'use strict'
    const userinfos = localStorage.getItem('userinfos');
    const parseUserInfos = JSON.parse(userinfos)
    if (!parseUserInfos) {
        window.location.replace("../inscription/index.html");
        return
    }

    const forms = document.querySelectorAll('.needs-validation')
    Array.from(forms).forEach(form => {
      form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
        const data = new FormData(forms);
        for (const [name,value] of data) {
            console.log(name, ":", value)
        }
      }, false)
    })
})()
